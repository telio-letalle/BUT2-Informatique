package fr.umontpellier.iut.tpjdbc;

import java.sql.*;

public class ConnexionBD {
    private Connection cn;
    private Statement st;
    private ResultSet rs;

    public ConnexionBD() {
        try {
            this.cn = DriverManager.getConnection("jdbc:oracle:thin:@162.38.222.149:1521:iut", "letallet", "22fVKu4CTc");
            this.st = cn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

            this.rs=st.executeQuery("SELECT * FROM Personnes ORDER BY agePersonne DESC NULLS LAST");
        }
        catch(SQLException e) {
            e.printStackTrace();
        }
    }

    public Personne creerPersonne(){
        try{
            int num = rs.getInt(1);
            String nom= rs.getString(2);
            String prenom= rs.getString(3);
            String nationnalite= rs.getString(4);
            int age = rs.getInt(5);
            if (rs.wasNull()) age = -1;
            return new Personne(num,nom,prenom,nationnalite,age);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    };
    public Personne premier(){
        try{
            if (rs.first()){
                return creerPersonne();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public Personne dernier(){
        try{
            if (rs.last()){
                return creerPersonne();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public Personne suivant(){
        try{
            if (!rs.isLast() && !rs.isAfterLast() && rs.next()){
                return creerPersonne();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public Personne precedent(){
        try{
            if (!rs.isFirst() && !rs.isBeforeFirst() && rs.previous()){
                return creerPersonne();
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public void deconnexion(){
        try {
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}